package com.cg.movie.daoServices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.movie.beans.Movie;



public interface moviedao extends JpaRepository<Movie,Integer> {

}
