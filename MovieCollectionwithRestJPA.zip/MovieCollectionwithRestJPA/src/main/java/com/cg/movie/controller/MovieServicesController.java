package com.cg.movie.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Songs;
import com.cg.movie.exceptions.movieNotFoundException;
import com.cg.movie.exceptions.songNotFoundException;
import com.cg.movie.services.MovieServices;


@Controller
public class MovieServicesController {
	@Autowired
private MovieServices services;
	@RequestMapping(value= {"/sayHello"},method=RequestMethod.GET)
	public ResponseEntity<String> sayHello()
	{
		return new ResponseEntity<String>("Hello World To All From REstImpl",HttpStatus.OK);
	}
	
@RequestMapping(value= "/getMovieDetails",method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<Movie> getMovieDetailsRequestParam(@RequestParam int movieId) throws movieNotFoundException{
		Movie movie=services.getMovieDetails(movieId);
		return new ResponseEntity<Movie>(movie,HttpStatus.OK);
	}
	@RequestMapping(value= "/acceptMovieDetails",method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>acceptMovieDetails(@ModelAttribute Movie movie)
	{
		movie=services.acceptMovieDetails(movie);
		return new ResponseEntity<>("Movie details successfully added movieId:"+movie.getMovieId(),HttpStatus.OK);
	}
	 @RequestMapping(value="/removeMovieDetails",method=RequestMethod.DELETE,
	            consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	    public ResponseEntity<String>removeMovieDetails(@RequestParam int movieId)throws movieNotFoundException
	    {
		 services.removeMovieDetails(movieId);
	        return new ResponseEntity<>("Movie details successfully removed",HttpStatus.OK);
	    }  
	 @RequestMapping(value= "/getAllMovieDetails",method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
		public ResponseEntity<List<Movie>> getAllMovieDetailsPathParam(){
			
			return new ResponseEntity<List<Movie>>(services.getAllMovieDetails(),HttpStatus.OK);
		}
	 @RequestMapping(value="/MovieSongsDetails",method=RequestMethod.GET,
	            consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE,headers="Accept=application/json")
	    public ResponseEntity<List<Songs>> MovieSongsDetails(@RequestParam int movieId)throws movieNotFoundException
	    {
		return new ResponseEntity<List<Songs>>( services.getMovieAllSongs(movieId),HttpStatus.OK);
		} 
	 @RequestMapping(value= {"/getSongDetails"},method=RequestMethod.GET,
			 produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
			 public ResponseEntity<Songs> getSongDetailsRequestParam(@RequestParam int songId) throws songNotFoundException{
			 Songs song = services.getSongDetails(songId);
			 return new ResponseEntity<Songs>(song,HttpStatus.OK);
			 }
	 @RequestMapping(value= {"/acceptSongDetails"},method=RequestMethod.POST,
			 consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
			 public ResponseEntity<String> acceptSongDetails(@ModelAttribute Songs song){
			 	song = services.acceptSongDetails(song);
			 return new ResponseEntity<>("Song details successfully added.\n Song ID: "+song.getSongId(),HttpStatus.OK);
			 }
	 @RequestMapping(value="/removeSongDetails",method=RequestMethod.DELETE,
		            consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	    public ResponseEntity<String>removeSongDetails(@RequestParam int songId)throws movieNotFoundException
		    {
		 services.removeMovieDetails(songId);
		        return new ResponseEntity<>("Songs details successfully removed",HttpStatus.OK);
		    }  
}
