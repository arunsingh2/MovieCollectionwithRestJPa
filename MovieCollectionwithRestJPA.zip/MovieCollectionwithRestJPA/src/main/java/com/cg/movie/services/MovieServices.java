package com.cg.movie.services;

import java.util.List;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Songs;


public interface MovieServices {
	public Movie acceptMovieDetails(Movie movie);
	public Movie getMovieDetails(int movieId);
	 List<Movie>getAllMovieDetails();
	public boolean removeMovieDetails(int movieId);
	
	public void updateMovieDetails(Movie movie);
	public List<Songs> getMovieAllSongs(int movieId);
	public Songs acceptSongDetails(Songs song);
	public Songs getSongDetails(int songId);
	 List<Songs>getAllSongsDetails();
	public boolean removeSongsDetails(int songId);

}
