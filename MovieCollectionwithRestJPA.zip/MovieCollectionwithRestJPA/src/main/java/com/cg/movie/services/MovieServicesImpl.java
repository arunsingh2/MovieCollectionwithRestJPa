package com.cg.movie.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Songs;
import com.cg.movie.daoServices.moviedao;
import com.cg.movie.daoServices.songsdao;
import com.cg.movie.exceptions.movieNotFoundException;
import com.cg.movie.exceptions.songNotFoundException;


@Component("services")
public class MovieServicesImpl implements MovieServices {
	@Autowired
	private moviedao movieDao;
	@Autowired
	private songsdao songdao;
	@Override
	public Movie acceptMovieDetails(Movie movie) {
		movie=movieDao.save(movie);
	
		return movie;
		
		
	}

	@Override
	public Movie getMovieDetails(int movieId) {
		return movieDao.findById(movieId).orElseThrow(()->new movieNotFoundException("movie details not found for id"+movieId));

		
	}

	@Override
	public boolean removeMovieDetails(int movieId) {
		movieDao.delete(getMovieDetails(movieId));
		return true;
	}

	@Override
	public void updateMovieDetails(Movie movie) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Movie> getAllMovieDetails() {
		
		return movieDao.findAll();
	}

	@Override
	public List<Songs> getMovieAllSongs(int movieId) {
		
		//ArrayList<Songs> list=new ArrayList<Songs>();
	Movie movie=movieDao.findById(movieId).orElseThrow(()->new movieNotFoundException("movie details not found for id"+movieId));
	ArrayList<Songs> list=new ArrayList<Songs>(movie.getSongs().values());
	//ArrayList<Songs> list=movie.getSongs();
	return	list;
//return list;
		
		
		//return songdao.find
	}

	@Override
	public Songs acceptSongDetails(Songs song) {
		song=songdao.save(song);
		
		return song;
	}

	@Override
	public Songs getSongDetails(int songId) {
		return songdao.findById(songId).orElseThrow(()->new songNotFoundException("song details not found for id"+songId));

	}

	@Override
	public List<Songs> getAllSongsDetails() {
		return songdao.findAll();
	}

	@Override
	public boolean removeSongsDetails(int songId) {
		songdao.delete(getSongDetails(songId));
		return true;
	}

	
	}

	
		
	


