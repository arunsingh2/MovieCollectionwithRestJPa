package com.cg.movie.exceptions;

public class songNotFoundException extends RuntimeException {

	public songNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public songNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public songNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public songNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public songNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
