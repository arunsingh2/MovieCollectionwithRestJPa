package com.cg.movie.daoServices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.movie.beans.Songs;



public interface songsdao extends JpaRepository<Songs,Integer> {

}
